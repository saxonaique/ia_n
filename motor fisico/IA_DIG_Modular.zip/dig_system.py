
from sensor_module import SensorModule
from memory_module import MemoryModule
from evolution_processor import EvolutionProcessor
from core_nucleus import CoreNucleus
from action_module import ActionModule
from meta_layer import MetaLayer

class DIGSystem:
    def __init__(self):
        self.sensors = SensorModule()
        self.memory = MemoryModule()
        self.processor = EvolutionProcessor(self.memory)
        self.nucleus = CoreNucleus()
        self.action = ActionModule()
        self.meta = MetaLayer()

    def run_cycle(self, input_source):
        self.sensors.load_input(input_source)
        field = self.sensors.translate_to_field()

        self.nucleus.receive_field(field)
        entropy = self.nucleus.compute_entropy()
        self.meta.monitor(entropy)

        if not self.nucleus.is_equilibrium():
            self.processor.receive_field(self.nucleus.field)
            evolved = self.processor.evolve()
            self.nucleus.receive_field(evolved)

        if self.nucleus.is_equilibrium():
            output = self.action.generate_output(self.nucleus.field)
            return output

        return None
