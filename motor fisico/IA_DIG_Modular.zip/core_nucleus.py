
class CoreNucleus:
    def __init__(self):
        self.field = None
        self.entropy = None

    def receive_field(self, field):
        self.field = field

    def compute_entropy(self):
        # Calcular entropía del campo
        return self.entropy

    def is_equilibrium(self, threshold=0.1):
        return self.entropy < threshold
