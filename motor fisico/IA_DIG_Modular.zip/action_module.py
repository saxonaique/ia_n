
class ActionModule:
    def __init__(self):
        self.output = None

    def generate_output(self, field):
        # Reorganizar campo → imagen, audio, texto
        return self.output
