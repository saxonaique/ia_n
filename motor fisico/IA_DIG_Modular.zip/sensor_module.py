
class SensorModule:
    def __init__(self):
        self.raw_data = None
        self.field_output = None

    def load_input(self, source):
        # Cargar EEG, WAV, imagen, etc.
        pass

    def translate_to_field(self):
        # Convertir a matriz informacional (-1, 0, +1)
        return self.field_output
