
import tkinter as tk
import numpy as np
import random

class FieldCanvas(tk.Canvas):
    def __init__(self, parent, rows=20, cols=20, cell_size=20, **kwargs):
        super().__init__(parent, width=cols*cell_size, height=rows*cell_size, **kwargs)
        self.rows = rows
        self.cols = cols
        self.cell_size = cell_size
        self.field = np.zeros((rows, cols))
        self.rects = [[None for _ in range(cols)] for _ in range(rows)]

    def draw_field(self, field):
        self.field = field
        for i in range(self.rows):
            for j in range(self.cols):
                color = self.get_color(field[i][j])
                if self.rects[i][j] is None:
                    x1, y1 = j*self.cell_size, i*self.cell_size
                    x2, y2 = x1+self.cell_size, y1+self.cell_size
                    self.rects[i][j] = self.create_rectangle(x1, y1, x2, y2, fill=color, outline="black")
                else:
                    self.itemconfig(self.rects[i][j], fill=color)

    def get_color(self, value):
        if value == -1:
            return "blue"
        elif value == 0:
            return "white"
        elif value == 1:
            return "red"
        else:
            return "gray"

class DIGVisualizer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("IA DIG - Visualizador Informacional")
        self.geometry("600x550")

        self.canvas_frame = FieldCanvas(self, rows=20, cols=20, cell_size=20)
        self.canvas_frame.pack(pady=10)

        self.entropy_label = tk.Label(self, text="Entropía: ---", font=("Arial", 12))
        self.entropy_label.pack()

        self.status_label = tk.Label(self, text="Estado: Inactivo", font=("Arial", 12))
        self.status_label.pack()

        self.control_btn = tk.Button(self, text="Iniciar", command=self.toggle)
        self.control_btn.pack(pady=10)

        self.running = False
        self.after_id = None

    def toggle(self):
        if self.running:
            self.running = False
            self.status_label.config(text="Estado: Pausado")
            if self.after_id:
                self.after_cancel(self.after_id)
            self.control_btn.config(text="Iniciar")
        else:
            self.running = True
            self.status_label.config(text="Estado: Procesando")
            self.control_btn.config(text="Pausar")
            self.run_cycle()

    def run_cycle(self):
        if not self.running:
            return

        field = np.random.choice([-1, 0, 1], size=(20, 20))  # campo simulado
        entropy = round(random.uniform(0, 1), 3)

        self.canvas_frame.draw_field(field)
        self.entropy_label.config(text=f"Entropía: {entropy}")

        self.after_id = self.after(500, self.run_cycle)

if __name__ == "__main__":
    app = DIGVisualizer()
    app.mainloop()
