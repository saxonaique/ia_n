#!/usr/bin/env python3
import pandas as pd, pymc as pm, arviz as az, numpy as np
df=pd.read_csv('results.csv'); GI=df['G_I'].values; GI_err=df['G_I_err'].values
with pm.Model() as model:
    mu=pm.Normal('mu', mu=GI.mean(), sigma=50)
    sigma=pm.HalfNormal('sigma', sigma=20)
    GI_true=pm.Normal('GI_true', mu=mu, sigma=sigma, shape=len(GI))
    obs=pm.Normal('obs', mu=GI_true, sigma=GI_err, observed=GI)
    idata=pm.sample(draws=2000, tune=1000, target_accept=0.9, return_inferencedata=True)
print(az.summary(idata, var_names=['mu','sigma'], hdi_prob=0.95))
idata.to_netcdf('hierarchical_GI_trace.nc')
