class GPTSooDecoder:
    def decode(self, tfc_data):
        # Aquí podríamos aplicar inferencias más complejas con IA, por ahora pasamos los datos tal cual
        return tfc_data